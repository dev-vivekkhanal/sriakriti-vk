const s_w =size_weight= [
    {
        size: "6.5",
        weight: "11.31",
        actual_price: "67407",
        sellingprice: "60666",
        id: 0,
    },
    {
        size: "7",
        weight: "12.18",
        actual_price: "72592",
        sellingprice: "65333",
        id: 1,
    },
    {
        size: "8",
        weight: "13.92",
        actual_price: "82962",
        sellingprice: "74666",
        id: 2,
    },
];