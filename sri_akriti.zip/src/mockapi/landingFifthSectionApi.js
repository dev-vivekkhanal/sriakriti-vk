import fifth_section_mobile from '../assets/images/fifth-section-mobile.png'

const fifth_section = {
    section_data: {
        first: 'Highly Skilled Labour',
        second: 'Higher Density',
        third: 'PURITY',
        section_image: fifth_section_mobile,
    }
};

export default fifth_section