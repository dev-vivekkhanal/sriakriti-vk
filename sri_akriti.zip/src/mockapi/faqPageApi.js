const faq_page = {
    section_data: [
        {
            title: 'QUESTIONS ABOUT PLATINUM',
            question_data: [
                {question: 'What is Platinum?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
                {question: 'What is the difference between Platinum, White Gold & Silver?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
                {question: 'Are my diamonds & rubies secure in Platinum?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
                {question: 'Since when has platinum been used in jewelary?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
                {question: 'Which celebrities don Platinum?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
            ]
        },
        {
            title: 'PURITY AND AUTHENTICITY',
            question_data: [
                {question: 'Pt 950 : What is it?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
                {question: 'How do I know my ring is made in platinum?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
                {question: 'Do you provide a certificate for platinum jewelry?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
            ]
        },
        {
            title: 'DIAMONDS',
            question_data: [
                {question: 'What is the difference between VVS GH & SI IJ diamond quality?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
                {question: 'Are your diamonds certified?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
            ]
        },
        {
            title: 'ORDERS, PAYMENTS AND DELIVERY',
            question_data: [
                {question: 'Are the prices inclusive of VAT?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
                {question: 'How do you accept payments?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
                {question: 'What is your return & exchange policy?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
                {question: 'Is the jewelry insured while shipping?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
                {question: 'Can I have the different jewelry items delivered to different locations?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
                {question: 'Can I see the bands in person?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
                {question: 'What is the platinum love bands price in India?', answer: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima odit officia minus sit nulla sint, id, deleniti quos explicabo magni sapiente, vero nemo. Doloremque quo dolorum dignissimos, in impedit placeat.',},
            ]
        },
    ]
};

export default faq_page