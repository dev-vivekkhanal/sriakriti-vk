import bracelet from "../assets/images/bracelet.png";
import chain from "../assets/images/chain.png";
import ring from "../assets/images/ring-1.png";

const collection_data = {
  filters: [
    {
      title: "M or F",
      checkbox: ["Womens Band only", "Mens Band only", "Couple Rings", "Unisex Rings"],
    },
    {
      title: "PRICE",
      checkbox: ["0-10,000", "10,000-20,000", "20,000-50,000", "Over 50,000"],
    },
    {
      title: "PRODUCT TYPE",
      checkbox: ["Chain", "Neckless", "Bracelet", "Rings"],
    },
    // {
    //   title: "M or F",
    //   checkbox: ["Womens Platinum bracelet", "Mens Platinum Bracelet"],
    // },
    {
      title: "METERIAL",
      checkbox: ["Plain Platinum Rings", "Plain Platinum Bracelets", "Diamond Jewellery", "Platinum & Gold Fusion Jewellery", "Men's Plain & Women's Diamond Ring", "Ruby", "Emerald", "Sapphire"],
    },
    {
      title:"DIAMOND SHAPE",
      checkbox:["Round Brilliant Cut", "Princess Cut", "Baguette Cut", "Emerald Cut"]
    }
  ],
  sort: [
    { title: 'Best Selling' },
    { title: 'Alphabeticaly, A - Z' },
    { title: 'Alphabeticaly, Z - A' },
    { title: 'Price, low to high' },
    { title: 'Price, high to low' },
    { title: 'Date, old to new' },
    { title: 'Date, new to old' },
  ],
  category: "ALL COLLECTION",
  // category: "NECKLACE",
  // category: "RINGS",
  // category: "EARRINGS",
  // category: "BRACELETS",

  category_details:
    "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
  category_image: bracelet,
  products: [
    {
      product_id: "2202",
      image: bracelet,
      name: "BR-bracelet-2202",
      price: 2000
  },
  {
      product_id: "2203",
      image: chain,
      name: "CH-necklace-2203",
      price: 23000
  },
  {
      product_id: "2204",
      image: bracelet,
      name: "BR-bracelet-2204",
      price: 5700
  },
  {
      product_id: "2205",
      image: chain,
      name: "CH-ring-2205",
      price: 9000
  },
  {
      product_id: "2206",
      image: bracelet,
      name: "BR-bracelet-2206",
      price: 16000
  },
  {
      product_id: "2102",
      image: chain,
      name: "CH-chain-2102",
      price: 2000
  },
  {
      product_id: "2303",
      image: bracelet,
      name: "BR-bracelet-2303",
      price: 23000
  },
  {
      product_id: "2404",
      image: chain,
      name: "CH-chain-2404",
      price: 5700
  },
  {
      product_id: "2505",
      image: bracelet,
      name: "BR-bracelet-2505",
      price: 9000
  },
  {
      product_id: "2606",
      image: chain,
      name: "CH-chain-2606",
      price: 16000
  },
  {
      product_id: "2702",
      image: bracelet,
      name: "BR-ring-2702",
      price: 2000
  },
  {
      product_id: "2803",
      image: chain,
      name: "CH-chain-2803",
      price: 23000
  },
  {
      product_id: "2904",
      image: bracelet,
      name: "BR-necklace-2904",
      price: 5700
  },
  {
      product_id: "2215",
      image: chain,
      name: "CH-chain-2215",
      price: 9000
  },
  {
      product_id: "2226",
      image: bracelet,
      name: "BR-bracelet-2226",
      price: 16000
  },
  ],
  res_data: [
    {
      id: 1073,
      name: "SA-BLC-002",
      image: chain,
      diamond_quality: "P",
      discount: "",
      weight: "11.31,12.18,13.92",
      diamond_size: "0.10",
      category: "bracelets"
    },
    {
      id: 1074,
      name: "SA-BLC-003",
      image: ring,
      diamond_quality: "P",
      discount: "",
      weight: "19.31,20.79,23.76",
      diamond_size: "0.03",
      category: "bracelets"
    },
    {
      id: 1075,
      name: "SA-BLC-004",
      image: bracelet,
      diamond_quality: "P",
      discount: "",
      weight: "17.32,18.66,21.32",
      diamond_size: "0.06",
      category: "bracelets"
    },
    {
      id: 1076,
      name: "SA-BLC-005",
      image: ring,
      diamond_quality: "P",
      discount: "",
      weight: "7.93,8.54,9.76",
      diamond_size: "0.03",
      category: "bracelets"
    },
    {
      id: 1077,
      name: "SA-BLC-006",
      image: bracelet,
      diamond_quality: "P",
      discount: "",
      weight: "7.43,8.01,9.15",
      diamond_size: "0.06",
      category: "bracelets"
    },
    {
      id: 1078,
      name: "SA-BLC-007",
      image: chain,
      diamond_quality: "P",
      discount: "",
      weight: "6.18,6.65,7.6",
      diamond_size: "0.10",
      category: "bracelets"
    },
    {
      id: 1079,
      name: "SA-BLC-008",
      image: bracelet,
      diamond_quality: "P",
      discount: "",
      weight: "8.43,9.08,10.38",
      diamond_size: "0.06",
      category: "bracelets"
    },
    {
      id: 1080,
      name: "SA-BLC-009",
      image: chain,
      diamond_quality: "P",
      discount: "",
      weight: "8,8.62,9.85",
      diamond_size: "0.10",
      category: "bracelets"
    },
    {
      id: 1081,
      name: "SA-BLC-011",
      image: chain,
      diamond_quality: "P",
      discount: "",
      weight: "3.14,3.38,3.86",
      diamond_size: "0.10",
      category: "bracelets"
    },
    {
      id: 1082,
      name: "SA-BLC-012",
      image: bracelet,
      diamond_quality: "P",
      discount: "",
      weight: "8.94,9.63,11",
      diamond_size: "0.06",
      category: "bracelets"
    },
    {
      id: 1083,
      name: "SA-BLC-013",
      image: chain,
      diamond_quality: "P",
      discount: "",
      weight: "9.2,9.91,11.32",
      diamond_size: "0.10",
      category: "bracelets"
    },
    {
      id: 1084,
      name: "SA-BLC-014",
      image: ring,
      diamond_quality: "P",
      discount: "",
      weight: "7.39,7.96,9.1",
      diamond_size: "0.03",
      category: "bracelets"
    },
    {
      id: 1085,
      name: "SA-BLC-015",
      image: chain,
      diamond_quality: "P",
      discount: "",
      weight: "8.53,9.19,10.5",
      diamond_size: "0.10",
      category: "bracelets"
    },
    {
      id: 1086,
      name: "SA-BLC-016",
      image: ring,
      diamond_quality: "P",
      discount: "",
      weight: "12.07,12.99,14.85",
      diamond_size: "0.03",
      category: "bracelets"
    },
    {
      id: 1087,
      name: "SA-BLC-017",
      image: chain,
      diamond_quality: "P",
      discount: "",
      weight: "11.46,12.35,14.11",
      diamond_size: "0.10",
      category: "bracelets"
    },
    {
      id: 1088,
      name: "SA-BLC-018",
      image: bracelet,
      diamond_quality: "P",
      discount: "",
      weight: "9.02,9.71,11.1",
      diamond_size: "0.06",
      category: "bracelets"
    },
    {
      id: 1089,
      name: "SA-BLC-019",
      image: chain,
      diamond_quality: "P",
      discount: "",
      weight: "7.68,8.27,9.45",
      diamond_size: "0.10",
      category: "bracelets"
    },
    {
      id: 1090,
      name: "SA-BLC-020",
      image: bracelet,
      diamond_quality: "P",
      discount: "",
      weight: "23.97,25.81,29.5",
      diamond_size: "0.06",
      category: "bracelets"
    },
    {
      id: 1091,
      name: "SA-BLC-021",
      image: chain,
      diamond_quality: "P",
      discount: "",
      weight: "3.1,3.34,3.82",
      diamond_size: "0.10",
      category: "bracelets"
    },
    {
      id: 1092,
      name: "SA-BLC-022",
      image: ring,
      diamond_quality: "P",
      discount: "",
      weight: "7.18,7.73,9.1",
      diamond_size: "0.03",
      category: "bracelets"
    },
    {
      id: 1093,
      name: "SA-BLC-023",
      image: bracelet,
      diamond_quality: "P",
      discount: "",
      weight: "5.57,6,6.86",
      diamond_size: "0.06",
      category: "bracelets"
    },
    {
      id: 1094,
      name: "SA-BLC-024",
      image: chain,
      diamond_quality: "P",
      discount: "",
      weight: "7.95,8.56,9.2",
      diamond_size: "0.10",
      category: "bracelets"
    },
    {
      id: 1095,
      name: "SA-BLC-025",
      image: ring,
      diamond_quality: "P",
      discount: "",
      weight: "6.7,7.22,8.25",
      diamond_size: "0.03",
      category: "bracelets"
    },
    {
      id: 1096,
      name: "SA-BLC-026",
      image: bracelet,
      diamond_quality: "P",
      discount: "",
      weight: "8.65,9.31,10.64",
      diamond_size: "0.06",
      category: "bracelets"
    },
    {
      id: 1097,
      name: "SA-BLC-027",
      image: chain,
      diamond_quality: "P",
      discount: "",
      weight: "5.84,6.29,7.19",
      diamond_size: "0.10",
      category: "bracelets"
    },
    {
      id: 1098,
      name: "SA-BLC-028",
      image: ring,
      diamond_quality: "P",
      discount: "",
      weight: "9.23,9.94,11.36",
      diamond_size: "0.03",
      category: "bracelets"
    },
    {
      id: 1099,
      name: "SA-BLC-029",
      image: bracelet,
      diamond_quality: "P",
      discount: "",
      weight: "6.34,6.83,7.8",
      diamond_size: "0.06",
      category: "bracelets"
    },
    {
      id: 1100,
      name: "SA-BLC-030",
      image: chain,
      diamond_quality: "P",
      discount: "",
      weight: "10.9,11.74,13.42",
      diamond_size: "0.10",
      category: "bracelets"
    },
    {
      id: 1101,
      name: "SA-BLC-031",
      image: ring,
      diamond_quality: "P",
      discount: "",
      weight: "7.81,8.41,9.61",
      diamond_size: "0.03",
      category: "bracelets"
    },
    {
      id: 1102,
      name: "SA-BLC-032",
      image: bracelet,
      diamond_quality: "P",
      discount: "",
      weight: "6.22,6.69,7.65",
      diamond_size: "0.06",
      category: "bracelets"
    },
    {
      id: 1103,
      name: "SA-BLC-033",
      image: chain,
      diamond_quality: "P",
      discount: "",
      weight: "11.55,12.43,14.21",
      diamond_size: "0.10",
      category: "bracelets"
    },
    {
      id: 1104,
      name: "SA-BLC-034",
      image: ring,
      diamond_quality: "P",
      discount: "",
      weight: "10.73,11.56,13.21",
      diamond_size: "0.03",
      category: "bracelets"
    },
    {
      id: 1105,
      name: "SA-BLC-035",
      image: bracelet,
      diamond_quality: "P",
      discount: "",
      weight: "6.29,6.77,7.74",
      diamond_size: "0.06",
      category: "bracelets"
    },
    {
      id: 1106,
      name: "SA-BLC-036",
      image: ring,
      diamond_quality: "P",
      discount: "",
      weight: "13.54,14.59,16.67",
      diamond_size: "0.03",
      category: "bracelets"
    },
  ],
};

export default collection_data;


