import grey from '../assets/icons/grey-rectangle.svg'

const addProductsAdminApi = {
    add_product : {
        main_img: grey,
        images: [grey, grey, grey]
    }
}

export default addProductsAdminApi