import { atom } from "recoil";

export const cartDataAtom = atom({
    key: 'cartDataAtom',
    default: [{}]
});