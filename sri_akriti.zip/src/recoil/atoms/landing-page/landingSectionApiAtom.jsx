import { atom } from "recoil";

const landingSectionApiAtom = atom({
    key: 'landingSectionApiAtom',
    default: null,
    
})

export default landingSectionApiAtom;